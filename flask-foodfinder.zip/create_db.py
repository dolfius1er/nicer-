import sqlite3

def create_database():
    conn = sqlite3.connect('recipes.db')
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )
    """)
    default_categories = ["Asian", "Vegetarian", "Dessert", "Fast Food"]
    for cat in default_categories:
        cursor.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (cat,))
    conn.commit()
    conn.close()
    print("✅ Database ready.")

if __name__ == "__main__":
    create_database()
